# allgraph/__init__.py
from .main import (
    make_bar_graph,
    make_line_graph,
    make_histogram,
    make_pie_chart,
    make_scatter_plot
)
